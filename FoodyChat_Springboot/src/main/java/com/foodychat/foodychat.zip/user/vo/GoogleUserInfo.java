package com.foodychat.user.vo;
//com.foodychat.user.dto.GoogleUserInfo.java

import lombok.Data;

@Data
public class GoogleUserInfo {
 private String email;
 private String name;
 private String googleId;
}
