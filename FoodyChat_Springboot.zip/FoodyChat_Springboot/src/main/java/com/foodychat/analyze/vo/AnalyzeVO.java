package com.foodychat.analyze.vo;

import lombok.Data;

/**
 * 사용자 정보 VO 클래스
 */
@Data
//@NoArgsConstructor
//@AllArgsConstructor
public class AnalyzeVO {
	/**입력 필요*/
}
