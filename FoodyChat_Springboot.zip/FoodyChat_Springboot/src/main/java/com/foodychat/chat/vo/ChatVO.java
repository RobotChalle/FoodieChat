package com.foodychat.chat.vo;

import lombok.Data;

/**
 * 사용자 정보 VO 클래스
 */
@Data
//@NoArgsConstructor
//@AllArgsConstructor
public class ChatVO {
	/* 입력필요 */
}
