package com.foodychat.chat.service;

import org.springframework.stereotype.Repository;

/**
 * 사용자 서비스 클래스
 */
@Repository
public interface ChatService {

}
