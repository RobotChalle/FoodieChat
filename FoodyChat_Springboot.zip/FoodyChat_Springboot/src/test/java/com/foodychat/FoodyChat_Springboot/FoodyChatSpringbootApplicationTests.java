package com.foodychat.FoodyChat_Springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodyChatSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
